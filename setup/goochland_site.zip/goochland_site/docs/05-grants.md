# Grants & Funding Opportunities

- **SARE Producer Grant** – up to $25 k  
- **VA FAIRS Value‑Added Ag** – match up to $250 k  
- **NIFA Community Food Projects** – up to $125 k  
- **Virginia Tourism Micro‑Grant** – $10‑20 k
