# Programs & Revenue Streams

- Field trips & STEM camps  
- CSA and U‑pick produce  
- Weddings & retreats  
- Festivals and farm‑to‑table dinners
