# Vision & Mission

Our mission is to cultivate curiosity and community through hands‑on learning, regenerative farming, and memorable events.